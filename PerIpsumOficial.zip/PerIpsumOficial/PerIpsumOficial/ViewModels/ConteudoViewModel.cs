﻿using PerIpsumOficial.Models;

namespace PerIpsumOficial.ViewModels
{
    public class ConteudoViewModel
    {
        public IEnumerable<ConteudoModel> Conteudos { get; set; }
        public ConteudoModel ConteudoM { get; set; }
    }
}
