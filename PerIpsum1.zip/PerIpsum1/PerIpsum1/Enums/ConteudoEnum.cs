﻿using System.ComponentModel.DataAnnotations;

namespace PerIpsum1.Enums
{
    public enum ConteudoEnum
    {
        Oportunidades = 1,
        Eventos = 2,
        Provas = 3
    }
}
