﻿using Microsoft.AspNetCore.Identity;

namespace PerIpsum1.Models
{
    public class UsuarioModel : IdentityUser
    {
        public string Nome { get; set; }
    }
}
