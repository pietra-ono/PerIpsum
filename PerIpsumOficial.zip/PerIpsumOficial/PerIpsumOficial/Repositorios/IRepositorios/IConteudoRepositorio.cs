﻿using PerIpsumOficial.Models;

namespace PerIpsumOficial.Repositorios.IRepositorios
{
    public interface IConteudoRepositorio
    {
        ConteudoModel AdicionarConteudo(ConteudoModel conteudo);
        ConteudoModel ListarPorId(int id);
        IEnumerable<ConteudoModel> GetAllConteudos();
        ConteudoModel Atualizar(ConteudoModel conteudo);
        bool Apagar(int id);
    }
}
