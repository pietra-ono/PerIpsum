﻿using PerIpsum1.Models;

namespace PerIpsum1.Repositorio
{
    public interface IConteudoRepositorio
    {
        ConteudoModel AdicionarConteudo(ConteudoModel conteudo);
        ConteudoModel ListarPorId(int id);
        IEnumerable<ConteudoModel> GetAllConteudos();
        ConteudoModel Atualizar(ConteudoModel conteudo);
        bool Apagar(int id);
    }
}
