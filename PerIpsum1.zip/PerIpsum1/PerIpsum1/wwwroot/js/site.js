﻿$(document).ready(function () {
    // Função de drag-and-drop para upload de imagens
    $('#imagem').on('dragover', function (e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });

    $('#imagem').on('dragleave', function (e) {
        $(this).removeClass('dragover');
    });

    $('#imagem').on('drop', function (e) {
        e.preventDefault();
        $(this).removeClass('dragover');

        var files = e.originalEvent.dataTransfer.files;
        if (files.length > 0) {
            var file = files[0];
            var formData = new FormData();
            formData.append('imagem', file);

            $.ajax({
                type: 'POST',
                url: '/Home/AdicionarConteudo',
                data: formData,
                contentType: false,
                processData: false,
                success: function (data) {
                    console.log('Upload realizado com sucesso!');
                    location.reload(); 
                },
                error: function (xhr, status, error) {
                    console.log('Erro ao realizar upload: ' + error);
                }
            });
        }
    });

    // Função para abrir modal de visualização
    $('#fundo').on('click', '#card', function () {
  
        var id = $(this).data('id');

   
        var imagem = $(this).find('#imagemCard').attr('src');
        var titulo = $(this).find('#textoTitulo').text();
        var descricao = $(this).find('#dataTextoDescricao').text();
        var data = $(this).find('#dataTexto').text();
        var pais = $(this).find('#paisTexto').text();
        var tipo = $(this).find('#tipoTexto').text();
        var link = $(this).find('#linkTexto').text();
        var bandeira = $(this).find('#paisDesign img').attr('src');

      
        var modal = $('#conteudoModal-' + id); 
        modal.find('#modalImage').attr('src', imagem);
        modal.find('#modalTitle').text(titulo);
        modal.find('#modalDescription').text(descricao);
        modal.find('#modalData').text(data);
        modal.find('#modalLink').attr('href', link);
        modal.find('#modalTipo').text(tipo).css('background-color', $(this).find('#tipoDesign').css('background-color'));
        modal.find('#modalPaisDisplay').text(pais);
        modal.find('#modalPaisFlag').attr('src', bandeira);

      
        modal.modal('show');
    });


    // Fechar modal ao clicar no botão de fechar
    $('.btn-close').click(function () {
        $('.modal').modal('hide');
    });



  

});