﻿using PerIpsumOficial.Data;
using PerIpsumOficial.Models;
using PerIpsumOficial.Repositorios.IRepositorios;

namespace PerIpsumOficial.Repositorios
{
    public class ConteudoRepositorio : IConteudoRepositorio
    {
        private readonly PerIpsumDbContext _dbContext;
       
        public ConteudoRepositorio(PerIpsumDbContext PerIpsumDbContext)
        {
            _dbContext = PerIpsumDbContext;
           
        }

        public ConteudoModel AdicionarConteudo(ConteudoModel conteudo)
        {
            _dbContext.Conteudo.Add(conteudo);
            _dbContext.SaveChanges();
            return conteudo;
        }

        public bool Apagar(int id)
        {
            ConteudoModel conteudoDB = ListarPorId(id);

            if (conteudoDB == null) throw new Exception("Erro na exclusão");

            _dbContext.Conteudo.Remove(conteudoDB);
            _dbContext.SaveChanges();
            return true;
        }

        public ConteudoModel Atualizar(ConteudoModel conteudo)
        {
            ConteudoModel conteudoDB = ListarPorId(conteudo.Id);

            if (conteudoDB == null) throw new Exception("Erro na atualização");

            conteudoDB.Nome = conteudo.Nome;
            conteudoDB.Descricao = conteudo.Descricao;
            conteudoDB.Imagem = conteudo.Imagem;
            conteudoDB.Pais = conteudo.Pais;
            conteudoDB.Tipo = conteudo.Tipo;
            conteudoDB.Link = conteudo.Link;
            conteudoDB.Data = conteudo.Data;

            _dbContext.Conteudo.Update(conteudoDB);
            _dbContext.SaveChanges();
            return conteudoDB;

        }

        public IEnumerable<ConteudoModel> GetAllConteudos()
        {
            return _dbContext.Conteudo.ToList();
        }

        public ConteudoModel ListarPorId(int id)
        {
            return _dbContext.Conteudo.FirstOrDefault(x => x.Id == id);
        }


    }
}
