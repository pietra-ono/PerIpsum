﻿using PerIpsum1.Models;

namespace PerIpsum1.ViewModels
{
    public class ConteudoViewModel
    {
        public IEnumerable<ConteudoModel> Conteudos { get; set; }
        public ConteudoModel ConteudoM { get; set; }
    }
}
