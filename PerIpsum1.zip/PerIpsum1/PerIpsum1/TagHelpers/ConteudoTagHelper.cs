﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using PerIpsum1.Enums;

namespace PerIpsum1.Helpers
{
    public static class EnumHelper
    {
        public static string GetColorForTipo(ConteudoEnum tipo)
        {
            return tipo switch
            {
                ConteudoEnum.Provas => "#009846",
                ConteudoEnum.Oportunidades => "#E2CB26",
                ConteudoEnum.Eventos => "#002279",
                _ => "gray"
            };
        }

        public static string GetTextForTipo(ConteudoEnum tipo)
        {
            return tipo switch
            {
                ConteudoEnum.Provas => "Prova",
                ConteudoEnum.Oportunidades => "Oport.",
                ConteudoEnum.Eventos => "Evento",
                _ => "desconhecido" 
            };
        }

        public static string GetFlagForCountry(PaisEnum pais)
        {
            return pais switch
            {
                PaisEnum.Brasil => "/images/bandeiras/brasil.svg",
                PaisEnum.China => "/images/bandeiras/china.svg",
                PaisEnum.EstadosUnidos => "/images/bandeiras/eua.svg",
                PaisEnum.Alemanha => "/images/bandeiras/alemanha.svg",
                PaisEnum.Japao => "/images/bandeiras/japao.svg",
                PaisEnum.India => "/images/bandeiras/india.svg",
                PaisEnum.ReinoUnido => "/images/bandeiras/uk.svg",
                PaisEnum.Franca => "/images/bandeiras/franca.svg",
                PaisEnum.Italia => "/images/bandeiras/italia.svg",
                PaisEnum.Canada => "/images/bandeiras/canada.svg",
                PaisEnum.Russia => "/images/bandeiras/russia.svg",
                PaisEnum.Mexico => "/images/bandeiras/mexico.svg",
                PaisEnum.CoreiaDoSul => "/images/bandeiras/cosul.svg",
                PaisEnum.Australia => "/images/bandeiras/australia.svg",
                PaisEnum.Espanha => "/images/bandeiras/espanha.svg",
                PaisEnum.Indonesia => "/images/bandeiras/indonesia.svg",
                PaisEnum.Turquia => "/images/bandeiras/turquia.svg",
                PaisEnum.Holanda => "/images/bandeiras/holanda.svg",
                PaisEnum.ArabiaSaudita => "/images/bandeiras/arab.svg",
                PaisEnum.Suica => "/images/bandeiras/suica.svg",
                PaisEnum.Portugal => "/images/bandeiras/portugal.svg",
                PaisEnum.Irlanda => "/images/bandeiras/irlanda.svg",
                PaisEnum.IrlandaDoNorte => "/images/bandeiras/uk.svg",
                PaisEnum.Chile => "/images/bandeiras/chile.svg",
                PaisEnum.Argentina => "/images/bandeiras/argentina.svg",
                _ => "/images/bandeiras/default.svg"
            };
        }
        public static string GetCountryDisplayName(PaisEnum pais)
        {
            return pais switch
            {
                PaisEnum.Brasil => "BRA",
                PaisEnum.EstadosUnidos => "EUA",
                PaisEnum.China => "CHI",
                PaisEnum.Alemanha => "ALE",
                PaisEnum.Japao => "JAP",
                PaisEnum.India => "IND",
                PaisEnum.ReinoUnido => "UK",
                PaisEnum.Franca => "FRA",
                PaisEnum.Italia => "ITA",
                PaisEnum.Canada => "CAN",
                PaisEnum.Russia => "RUS",
                PaisEnum.Mexico => "MEX",
                PaisEnum.CoreiaDoSul => "CORS",
                PaisEnum.Australia => "AUS",
                PaisEnum.Espanha => "ESP",
                PaisEnum.Indonesia => "INDO",
                PaisEnum.Turquia => "TURQ",
                PaisEnum.Holanda => "HOL",
                PaisEnum.ArabiaSaudita => "ARAB",
                PaisEnum.Suica => "SUI",
                PaisEnum.Portugal => "POR",
                PaisEnum.Irlanda => "IRL",
                PaisEnum.IrlandaDoNorte => "IRLN",
                PaisEnum.Chile => "CHIL",
                PaisEnum.Argentina => "ARG",
                _ => "Desconhecido"
            };
        }
    }
}

