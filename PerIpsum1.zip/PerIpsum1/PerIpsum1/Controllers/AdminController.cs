﻿using Microsoft.AspNetCore.Mvc;

namespace PerIpsum1.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
