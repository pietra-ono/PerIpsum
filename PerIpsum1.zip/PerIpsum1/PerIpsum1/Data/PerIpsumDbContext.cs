﻿using Microsoft.EntityFrameworkCore;
using PerIpsum1.Data.Map;
using PerIpsum1.Models;

namespace PerIpsum1.Data
{
    public class PerIpsumDbContext : DbContext
    {
        public PerIpsumDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<ConteudoModel> Conteudo { get; set;}
        public DbSet<ConteudoAprovarModel> ConteudoAprovar { get; set;}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ConteudoMaps());

            base.OnModelCreating(modelBuilder);
        }
    }
}
