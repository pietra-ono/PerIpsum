﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PerIpsum1.Data.Map;
using PerIpsum1.Models;

namespace PerIpsum1.Data
{
    public class PerIpsumDbContext : IdentityDbContext<UsuarioModel>
    {
        public PerIpsumDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<ConteudoModel> Conteudo { get; set;}
        public DbSet<ConteudoAprovarModel> ConteudoAprovar { get; set;}
        public DbSet<AnotacaoModel> Anotacoes { get; set;}
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ConteudoMaps());
            modelBuilder.ApplyConfiguration(new ConteudoAprovarMaps());
            modelBuilder.ApplyConfiguration(new AnotacaoMaps());
            modelBuilder.Entity<AnotacaoModel>()
                .HasOne(a => a.Usuario)
                .WithMany()
                .HasForeignKey(a => a.UsuarioId);


            base.OnModelCreating(modelBuilder);
        }
    }
}
