﻿using PerIpsumOficial.Models;

namespace PerIpsumOficial.Repositorios.IRepositorios
{
    public interface IConteudoAprovarRepositorio
    {
        ConteudoAprovarModel AdicionarConteudoTemporario(ConteudoAprovarModel conteudoAprovar);
        bool ApagarTemporario(int id);
        IEnumerable<ConteudoAprovarModel> GetAllConteudosTemporarios();
        ConteudoAprovarModel ListarPorIdTemporario(int id);
    }
}
