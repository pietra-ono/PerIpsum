﻿using PerIpsum1.Data;
using PerIpsum1.Models;

namespace PerIpsum1.Repositorio
{
    public class AnotacaoRepositorio : IAnotacaoRepositorio
    {
        private readonly PerIpsumDbContext _context;

        public AnotacaoRepositorio(PerIpsumDbContext context)
        {
            _context = context;
        }

        public IEnumerable<AnotacaoModel> ObterAnotacoesPorUsuario(string usuarioId)
        {
            return _context.Anotacoes.Where(a => a.UsuarioId == usuarioId).ToList();
        }

        public void AdicionarAnotacao(AnotacaoModel anotacao)
        {
            _context.Anotacoes.Add(anotacao);
            _context.SaveChanges();
        }
    }
}
