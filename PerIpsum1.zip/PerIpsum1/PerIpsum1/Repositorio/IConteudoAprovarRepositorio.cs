﻿using PerIpsum1.Models;

namespace PerIpsum1.Repositorio
{
    public interface IConteudoAprovarRepositorio
    {
        ConteudoAprovarModel AdicionarConteudoTemporario(ConteudoAprovarModel conteudoAprovar);
        bool ApagarTemporario(int id);
        IEnumerable<ConteudoAprovarModel> GetAllConteudosTemporarios();
        ConteudoAprovarModel ListarPorIdTemporario(int id);
    }
}
