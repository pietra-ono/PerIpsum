using Microsoft.AspNetCore.Mvc;
using PerIpsum1.Data;
using PerIpsum1.Models;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;
using System.Drawing;
using Microsoft.EntityFrameworkCore;
using PerIpsum1.Repositorio;
using PerIpsum1.ViewModels;

namespace PerIpsum1.Controllers
{

    public class HomeController : Controller
    {
        private readonly IConteudoRepositorio _conteudoRepositorio;
        private readonly IConteudoAprovarRepositorio _conteudoAprovarRepositorio;
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _environment;

        public HomeController(IConteudoRepositorio conteudoRepositorio, IConteudoAprovarRepositorio conteudoAprovarRepositorio, ILogger<HomeController> logger, IWebHostEnvironment environment)
        {
            _conteudoRepositorio = conteudoRepositorio;
            _conteudoAprovarRepositorio = conteudoAprovarRepositorio;
            _logger = logger;
            _environment = environment;
        }

        public IActionResult Index()
        {
            var conteudos = _conteudoRepositorio.GetAllConteudos();
            var viewModel = new ConteudoViewModel
            {
                Conteudos = conteudos
            };
            return View(viewModel);
    }

        public IActionResult Feed(int id)
        {
            ConteudoModel conteudo = _conteudoRepositorio.ListarPorId(id);
            return View(conteudo);
        }

        [HttpPost]
        public IActionResult AlterarConteudo(ConteudoModel conteudo, IFormFile imagem)
        {
            
            var conteudoAtual = _conteudoRepositorio.ListarPorId(conteudo.Id);

            if (conteudoAtual != null && imagem != null)
            {
           
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "Imagens");


                if (!string.IsNullOrEmpty(conteudoAtual.Imagem))
                {
                    string imagemAntigaPath = Path.Combine(uploadsFolder, conteudoAtual.Imagem);
                    if (System.IO.File.Exists(imagemAntigaPath))
                    {
                        System.IO.File.Delete(imagemAntigaPath);
                    }
                }

         
                string novoNomeImagem = Guid.NewGuid().ToString() + "_" + imagem.FileName;
                string novaImagemPath = Path.Combine(uploadsFolder, novoNomeImagem);

                using (var stream = new FileStream(novaImagemPath, FileMode.Create))
                {
                    imagem.CopyTo(stream);
                }

             
                conteudo.Imagem = novoNomeImagem;
            }
            else
            {
            
                conteudo.Imagem = conteudoAtual.Imagem;
            }

   
            _conteudoRepositorio.Atualizar(conteudo);
            return RedirectToAction("Index");
        }



        [HttpPost]
        public IActionResult AdicionarConteudo(ConteudoAprovarModel conteudoAprovar, IFormFile imagem)
        {
            if (imagem != null)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "Imagens");
                string filePath = Guid.NewGuid().ToString() + "_" + imagem.FileName;
                string fullPath = Path.Combine(uploadsFolder, filePath);

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    imagem.CopyTo(stream);
                }

                conteudoAprovar.Imagem = filePath;
            }
            _conteudoAprovarRepositorio.AdicionarConteudoTemporario(conteudoAprovar);
            return RedirectToAction("Index");
        }

        public IActionResult Sobre(int id)
        {
            ConteudoModel conteudo = _conteudoRepositorio.ListarPorId(id);
            return View(conteudo);
        }

        public IActionResult ApagarConteudo(int id)
        {
            var conteudo = _conteudoRepositorio.ListarPorId(id);

            if (conteudo != null)
            {
                // Caminho completo da imagem no diret�rio wwwroot/Imagens
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "Imagens");
                string filePath = Path.Combine(uploadsFolder, conteudo.Imagem);

                // Verifica se o arquivo existe e o exclui
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }

                // Apaga o conte�do do reposit�rio
                _conteudoRepositorio.Apagar(id);
            }

            return RedirectToAction("Index");
        }

        public IActionResult Aprovacao()
        {
            var conteudosTemp = _conteudoAprovarRepositorio.GetAllConteudosTemporarios();
            return View(conteudosTemp);
        }

        [HttpPost]
        public IActionResult AprovarConteudo(int id)
        {
            // Obter o conte�do tempor�rio
            var conteudoTemp = _conteudoAprovarRepositorio.ListarPorIdTemporario(id);

            // Criar um novo ConteudoModel e salvar no banco principal
            if (conteudoTemp != null)
            {
                var conteudo = new ConteudoModel
                {
                    Nome = conteudoTemp.Nome,
                    Descricao = conteudoTemp.Descricao,
                    Imagem = conteudoTemp.Imagem,
                    Link = conteudoTemp.Link,
                    Tipo = conteudoTemp.Tipo,
                    Pais = conteudoTemp.Pais,
                    Data = conteudoTemp.Data
                };

                _conteudoRepositorio.AdicionarConteudo(conteudo);
                _conteudoAprovarRepositorio.ApagarTemporario(id);
            }

            return RedirectToAction("Aprovacao");
        }

        [HttpPost]
        public IActionResult RejeitarConteudo(int id)
        {
            var conteudoAprovar = _conteudoAprovarRepositorio.ListarPorIdTemporario(id);

            if (conteudoAprovar != null)
            {
                // Caminho completo da imagem no diret�rio wwwroot/Imagens
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "Imagens");
                string filePath = Path.Combine(uploadsFolder, conteudoAprovar.Imagem);

                // Verifica se o arquivo existe e o exclui
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }

                // Apaga o conte�do do reposit�rio
                _conteudoAprovarRepositorio.ApagarTemporario(id);
            }

            return RedirectToAction("Aprovacao");
        }


        public IActionResult Calendario()
        {
            return View();
        }

        public IActionResult Contato()
        {
            return View();
        }


            [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
