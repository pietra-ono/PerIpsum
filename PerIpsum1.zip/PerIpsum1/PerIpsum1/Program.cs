using Microsoft.EntityFrameworkCore;
using PerIpsum1.Data;
using PerIpsum1.Repositorio;
using Microsoft.AspNetCore.Identity;
using PerIpsum1.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddScoped<IConteudoRepositorio, ConteudoRepositorio>();
builder.Services.AddScoped<IConteudoAprovarRepositorio, ConteudoAprovarRepositorio>();
builder.Services.AddScoped<IAnotacaoRepositorio, AnotacaoRepositorio>();

builder.Services.AddDbContext<PerIpsumDbContext>(options =>
{
    var connectionString = builder.Configuration.GetConnectionString("DataBase");
    options.UseSqlServer(connectionString);
});

builder.Services.AddDefaultIdentity<UsuarioModel>(options => options.SignIn.RequireConfirmedAccount = false)
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<PerIpsumDbContext>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();
app.Run();
