﻿using PerIpsum1.Models;

namespace PerIpsum1.Repositorio
{
    public interface IAnotacaoRepositorio
    {
        IEnumerable<AnotacaoModel> ObterAnotacoesPorUsuario(string usuarioId);
        void AdicionarAnotacao(AnotacaoModel anotacao);
    }
}
