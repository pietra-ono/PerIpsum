﻿using Microsoft.EntityFrameworkCore;
using PerIpsumOficial.Data.Maps;
using PerIpsumOficial.Models;

namespace PerIpsumOficial.Data
{
    public class PerIpsumDbContext : DbContext
    {
        public PerIpsumDbContext(DbContextOptions options) : base(options) 
        {
        }

        public DbSet<ConteudoModel> Conteudo { get; set; }
        public DbSet<ConteudoAprovarModel> ConteudoAprovar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ConteudoMap());
            modelBuilder.ApplyConfiguration(new ConteudoAprovarMap());
            base.OnModelCreating(modelBuilder);
        }
    }
}
