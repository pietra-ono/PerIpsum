﻿namespace PerIpsumOficial.Enums
{
    public enum TipoEnum
    {
        Oportunidades = 1,
        Eventos = 2,
        Provas = 3
    }
}
