﻿using Microsoft.EntityFrameworkCore;
using PerIpsum1.Data;
using PerIpsum1.Models;

namespace PerIpsum1.Repositorio
{
    public class ConteudoAprovarRepositorio : IConteudoAprovarRepositorio
    {
        private readonly PerIpsumDbContext _dbContext;
        public ConteudoAprovarRepositorio(PerIpsumDbContext PerIpsumDbContext)
        {
            _dbContext = PerIpsumDbContext;
        }

        public ConteudoAprovarModel AdicionarConteudoTemporario(ConteudoAprovarModel conteudoAprovar)
        {
            _dbContext.ConteudoAprovar.Add(conteudoAprovar);
            _dbContext.SaveChanges();
            return conteudoAprovar;
        }

        public bool ApagarTemporario(int id)
        {
            ConteudoAprovarModel conteudoDB = ListarPorIdTemporario(id);

            if (conteudoDB == null) throw new Exception("Erro na exclusão");

            _dbContext.ConteudoAprovar.Remove(conteudoDB);
            _dbContext.SaveChanges();
            return true;
        }

        public IEnumerable<ConteudoAprovarModel> GetAllConteudosTemporarios()
        {
            return _dbContext.ConteudoAprovar.ToList();
        }

        public ConteudoAprovarModel ListarPorIdTemporario(int id)
        {
            return _dbContext.ConteudoAprovar.FirstOrDefault(x => x.Id == id);
        }
    }
}
