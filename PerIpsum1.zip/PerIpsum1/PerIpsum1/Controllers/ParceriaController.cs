﻿using Microsoft.AspNetCore.Mvc;

namespace PerIpsum1.Controllers
{
    public class ParceriaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
