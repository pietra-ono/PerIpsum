﻿namespace PerIpsumOficial.Enums
{
    public enum PaisEnum
    {
        EstadosUnidos = 1,
        China = 2,
        Alemanha = 3,
        Japao = 4,
        India = 5,
        ReinoUnido = 6,
        Franca = 7,
        Italia = 8,
        Brasil = 9,
        Canada = 10,
        Russia = 11,
        Mexico = 12,
        CoreiaDoSul = 13,
        Australia = 14,
        Espanha = 15,
        Indonesia = 16,
        Turquia = 17,
        Holanda = 18,
        ArabiaSaudita = 19,
        Suica = 20,
        Portugal = 21,
        Irlanda = 22,
        IrlandaDoNorte = 23,
        Chile = 24,
        Argentina = 25
    }
}
